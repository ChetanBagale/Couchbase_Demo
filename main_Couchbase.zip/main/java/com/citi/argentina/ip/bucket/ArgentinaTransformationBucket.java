package com.citi.argentina.ip.bucket;

import com.citi.argentina.ip.model.User;

public interface ArgentinaTransformationBucket {

	public String saveOrUpdate(User userDetails, String userDetailsJsonString);

	public User getAndTouch(String docId);

	public User remove(String docId);
}
