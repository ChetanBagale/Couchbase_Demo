package com.citi.argentina.ip.bucket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.citi.argentina.ip.model.User;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.document.JsonDocument;
import com.couchbase.client.java.document.RawJsonDocument;
import com.couchbase.client.java.document.json.JsonObject;
import com.fasterxml.jackson.databind.ObjectMapper;

/*
 * Bucket Operations will be performed like: 1)create() and update()---with TTL 2)getAndTouch()---with TTL 3)remove
 */

@Repository
public class ArgentinaTransformationBucketImpl implements ArgentinaTransformationBucket {

	private Bucket bucket;
	@Autowired
	private ObjectMapper objectMapper;
	@Value("${TTL}")
	private Integer TTL;
	@Value("${spring.couchbase.bucket.name}")
	private String bucketName;
	@Value("${spring.couchbase.bucket.password}")
	private String bucketPassword;
	@Autowired
	private Cluster cluster;
	private static final Logger LOGGER = LoggerFactory.getLogger(ArgentinaTransformationBucketImpl.class);

	private Bucket getBucket() {

		LOGGER.info("ArgentinaTransformationBucketImpl:'getBucket' method. Open Connection");
		return cluster.openBucket(bucketName, bucketPassword);
	}

	/* Method to update or save document*/
	@Override
	public String saveOrUpdate(User user, String userJsonStr) {

		LOGGER.info("ArgentinaTransformationBucketImpl:'saveOrUpdate' method " + userJsonStr);

		bucket = getBucket();
		
		if(user.getUserId()!=null)
		{
			/* Storing with TTL*/
		RawJsonDocument document = RawJsonDocument.create("DOC:" + user.getUserId(), TTL, userJsonStr);
		bucket.upsert(document);
		return "User with DOC Id:DOC:" + user.getUserId() + " created";
		} else {
			return "Document not created for NULL object";
		}
	}

	/*Method to get document from couchbase and extend to expiry time */
	@Override
	public User getAndTouch(String docId) {

		LOGGER.info("ArgentinaTransformationBucketImpl:'getAndTouch' method");
		User user = null;
		bucket = getBucket();

		/* getAndTouch(String docId,int expiry):get the desired document with docId 
		                                        and extend the expiry time 
		  */
		JsonDocument jsonDocument = bucket.getAndTouch(docId, TTL);
		/*if jsonDocument is null then document is not present*/
		if (jsonDocument == null) {
			LOGGER.info("ArgentinaTransformationBucketImpl:'getAndTouch' method document not available");
		} else {
			LOGGER.info("ArgentinaTransformationBucketImpl:'getAndTouch' method document accessed:" + jsonDocument);
			JsonObject jsonObject = jsonDocument.content();
			String jsonString = jsonObject.toString();
			try {
				/*converting document into object*/
				user = objectMapper.readValue(jsonString, User.class);
			} catch (Exception e) {
			}
		}

		return user;
	}

	@Override
	public User remove(String docId) {

		bucket = getBucket();
		System.out.println("DOCUMENT=" + docId);
		User user = null;
		JsonDocument jsonDocument = bucket.get(docId);
		if (jsonDocument == null) {
			LOGGER.info("ArgentinaTransformationBucketImpl:'remove' method document not available");
			LOGGER.info("ArgentinaTransformationBucketImpl:'remove' method Document with DOC ID:" + docId + " not present");
		} else {
			System.out.println(jsonDocument);
			JsonObject jsonObject = jsonDocument.content();
			String jsonString = jsonObject.toString();
			try {
				user = objectMapper.readValue(jsonString, User.class);
			} catch (Exception ex) {
				LOGGER.error("ArgentinaTransformationBucketImpl:'remove' method", ex.getMessage());
			}
			bucket.remove(docId);

		}
		bucket.close();
		return user;
	}
}
