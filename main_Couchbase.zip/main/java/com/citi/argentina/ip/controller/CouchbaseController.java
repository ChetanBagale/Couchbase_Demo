package com.citi.argentina.ip.controller;


import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.argentina.ip.model.User;
import com.citi.argentina.ip.session.UserSession;

@RestController
@RequestMapping("/api")
public class CouchbaseController 
{

	private static final Logger LOGGER = LoggerFactory.getLogger(CouchbaseController.class);
	@Autowired
	private UserSession userSession;

	/* create document */
	@PostMapping("/create")
	public String create(@Valid @RequestBody User userDetails) 
	{

		LOGGER.info("CouchbaseController:'create' method " + userDetails.toString());
		return userSession.saveOrUpdate(userDetails);
	}
	
	/*  Get Document by providing docId */
	@GetMapping("/get/{docId}")
	@ResponseBody
	public User get(@PathVariable("docId") String docId)
	{

		LOGGER.info("CouchbaseController:'get' method " + docId);

		int id = 0;
		try
		{
			id = Integer.parseInt(docId);
		}
		catch(NumberFormatException ex)
		{
			LOGGER.info("CouchbaseController:'get' method NumberFormatException " + docId);
			return null;
		}
		return userSession.getAndTouch("DOC:" + id);
	}
	
	/*  Update Document  */
	@PutMapping("/update")
	public String update(@RequestBody User userDetails)
	{

		LOGGER.info("CouchbaseController:'update' method " + userDetails);
		return userSession.saveOrUpdate(userDetails);
	}
	
	/*Delete Document*/
	@DeleteMapping("/delete/{docId}")
	public User delete(@PathVariable int docId) {

		LOGGER.info("CouchbaseController:'delete' method " + docId);
		return userSession.remove("DOC:" + docId);
	}
	
	
}
