package com.citi.argentina.ip.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.env.CouchbaseEnvironment;
import com.couchbase.client.java.env.DefaultCouchbaseEnvironment;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
//@PropertySource(value = "file:${CONFIG}/config.properties", ignoreResourceNotFound = false)
public class CouchbaseConfig {

	@Value("${spring.couchbase.bootstrap-hosts}")
	private String host;

	private final static CouchbaseEnvironment env = DefaultCouchbaseEnvironment.builder().connectTimeout(20000).build();

	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

	@Bean
	public Cluster cluster() {

		Cluster cluster = CouchbaseCluster.create(env, host);
		env.shutdown();
		return cluster;
	}



}

