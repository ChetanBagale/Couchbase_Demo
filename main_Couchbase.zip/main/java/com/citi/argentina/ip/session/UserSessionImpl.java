package com.citi.argentina.ip.session;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.argentina.ip.bucket.ArgentinaTransformationBucket;
import com.citi.argentina.ip.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UserSessionImpl implements UserSession 
{

	private static final Logger LOGGER = LoggerFactory.getLogger(UserSessionImpl.class);
	@Autowired
	private ArgentinaTransformationBucket argentinaTransformationBucket;
	@Autowired
	private ObjectMapper objectMapper;

	/*this method converts User Object into json string and delegate method call*/
	/*
	 *  @param:User user
	 * */
	@Override
	public String saveOrUpdate(User user) 
	{
		 String userJsonStr=null;		  
	        try 
	        { 
	            // get object as a json string 
			userJsonStr = objectMapper.writeValueAsString(user);
	            
	            // Displaying JSON String 
			LOGGER.info("UserSessionImpl:'saveOrUpdate' method User Object Json String" + userJsonStr);

	        } 
	        catch (IOException e) 
		{
			LOGGER.error("UserSessionImpl:'saveOrUpdate' method " + e.getMessage());
			LOGGER.error("UserSessionImpl:'saveOrUpdate' method " + e);
			//	e.printStackTrace();
		}
		return argentinaTransformationBucket.saveOrUpdate(user, userJsonStr);
	}

	@Override
	public User getAndTouch(String docId) {

		return argentinaTransformationBucket.getAndTouch(docId);
	}

	@Override
	public User remove(String docId) {

		return argentinaTransformationBucket.remove(docId);
	}
	
}
