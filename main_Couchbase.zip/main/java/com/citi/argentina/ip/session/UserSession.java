package com.citi.argentina.ip.session;

import com.citi.argentina.ip.model.User;

public interface UserSession 
{


	public String saveOrUpdate(User user);

	public User getAndTouch(String docId);

	public User remove(String docId);

}
