package com.citi.argentina.ip.error;


public class DocumentErrorResponse {
}
