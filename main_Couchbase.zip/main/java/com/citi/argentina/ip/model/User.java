package com.citi.argentina.ip.model;

import java.io.Serializable;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class User implements Serializable
{

	@NotNull(message = "{message.userId}")
	private Integer userId;

	@NotEmpty(message = "{message.firstName}")
	private String firstName;

	@NotEmpty(message = "{message.lastName}")
	private String lastName;

	private String city;

	@Pattern(regexp = "^[0][1-9]\\d{9}$|^[1-9]\\d{9}$", message = "{message.mobileNo}")
	private String mobNo;

	@Email(message = "{message.emailId}")
	private String emailId;

	private String country;

	private String state;

	@Pattern(regexp = "^[1-9][0-9]{5}$", message = "{message.pinCode}")
	private String pinCode;

	private static final long serialVersionUID = 1L;

	public User() {

	}

	public User(int userId, String firstName, String lastName, String city, String mobNo, String emailId, String country, String pinCode, String state) {

		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.city = city;
		this.mobNo = mobNo;
		this.emailId = emailId;
		this.country = country;
		this.pinCode = pinCode;
		this.state = state;
	}

	public String getState() {

		return this.state;

	}

	public void setState(String state)
	{

		this.state = state;

	}

	public String getMobNo() {

		return mobNo;
	}

	public void setMobNo(String mobNo) {

		this.mobNo = mobNo;
	}

	public String getEmailId() {

		return emailId;
	}

	public void setEmailId(String emailId) {

		this.emailId = emailId;
	}

	public String getCountry() {

		return country;
	}

	public void setCountry(String country) {

		this.country = country;
	}

	public String getPinCode() {

		return pinCode;
	}

	public void setPinCode(String pinCode) {

		this.pinCode = pinCode;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
